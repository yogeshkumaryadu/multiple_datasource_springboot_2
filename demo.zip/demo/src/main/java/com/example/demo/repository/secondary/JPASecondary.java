package com.example.demo.repository.secondary;

import org.springframework.data.repository.CrudRepository;

import com.example.demo.model.primary.PrimaryModel;
import com.example.demo.model.secondary.SecondaryModel;

public interface JPASecondary extends CrudRepository<SecondaryModel, String> {

}
