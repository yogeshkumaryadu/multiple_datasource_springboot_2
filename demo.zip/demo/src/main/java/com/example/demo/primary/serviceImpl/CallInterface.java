package com.example.demo.primary.serviceImpl;

import org.springframework.stereotype.Component;

@Component
public interface CallInterface {

	public String callSomething();
}
