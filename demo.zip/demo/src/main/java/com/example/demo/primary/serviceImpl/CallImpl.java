package com.example.demo.primary.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.primary.PrimaryModel;
import com.example.demo.model.secondary.SecondaryModel;
import com.example.demo.repository.primary.JPAPrimary;
import com.example.demo.repository.secondary.JPASecondary;

@Service
public class CallImpl implements CallInterface {

	@Autowired
	JPASecondary jpaSec;

	@Autowired
	JPAPrimary prim;

	@Override
	public String callSomething() {
		// TODO Auto-generated method stub

		PrimaryModel m = new PrimaryModel();
		m.setId("5");
		m.setPw("fasfd");

		SecondaryModel s = new SecondaryModel();
		s.setId("345");
		s.setPw("fasf");
		jpaSec.save(s);

		prim.save(m);

		return "Called";
	}

}
