package com.example.demo.repository.primary;

import org.springframework.data.repository.CrudRepository;

import com.example.demo.model.primary.PrimaryModel;

public interface JPAPrimary extends CrudRepository<PrimaryModel, String> {

}
