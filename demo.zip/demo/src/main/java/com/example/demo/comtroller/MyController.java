package com.example.demo.comtroller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.primary.serviceImpl.CallInterface;

@RestController
@RequestMapping("/test")
public class MyController {
	@Autowired
	CallInterface call;

	@GetMapping("/test")
	public String test() {
		call.callSomething();
		return "Helloo";
	}
}
